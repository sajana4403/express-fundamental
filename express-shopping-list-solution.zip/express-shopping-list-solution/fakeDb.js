global.items = []

module.exports = items